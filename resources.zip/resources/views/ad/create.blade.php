
@extends('dashboard.game_ui')

@section("title") Game & Software Zone Myanmar @endsection

@section('content')
    <div class="container py-5">
        <div class="row justify-content-center border border-dark" style="background: rgba(11,15,18,0.6); padding: 111px 20px;">
            <h1 class="col-12 my-3 pt-3 text-center text-white " style="line-height: 65px;">We Accept Advertising Services... </h1>
            <h2 class="col-12 my-3  text-center text-white" style="line-height: 55px;">If You Want More Details....</h2>
            <h2 class="col-12 my-1  text-center text-white " style="line-height: 55px;"> Phone Number : <a href="tel:09795519052" style="text-decoration: none;">09796519052</a> </h2>
            <h2 class="col-12 my-1 text-center text-white " style="line-height: 50px;"> Facebook Account : <a style="text-decoration: none;" href="https://www.facebook.com/profile.php?id=100059336683324">Aung Htet Chon</a> </h2>
        </div>
    </div>



@endsection




